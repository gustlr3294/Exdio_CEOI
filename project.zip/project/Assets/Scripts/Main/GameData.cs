﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;

[Serializable]
public class PlayerInfo
{
    public float hp;
    public float damage;
    public float defense;
    public float criAttackPercent;
    public float evasion;
    public float speed;
    public float jumpPower;
}

[Serializable]
public class EnemyInfo
{
    public float hp;
    public float damage;
    public float defense;
    public float speed;

    public EnemyInfo() { }
    public EnemyInfo(EnemyInfo other)
    {
        this.hp = other.hp;
        this.damage = other.damage;
        this.defense = other.defense;
        this.speed = other.speed;
    }
}

public class GameData : MonoBehaviour
{
    private static GameData _instance = null;

    public PlayerInfo playerInfo;
    public Hashtable enemyInfoTable;

    public static GameData Instance
    {
        get
        {
            if(_instance == null)
            {
                _instance = FindObjectOfType<GameData>();
                if(_instance == null)
                {
                    Debug.LogError("There's no exists active object");
                }
                string path = Path.Combine(Application.dataPath, "Data/PlayerInfo.json");
                _instance.playerInfo = JsonUtility.FromJson<PlayerInfo>(File.ReadAllText(path));
                
                _instance.enemyInfoTable = new Hashtable();

                path = Path.Combine(Application.dataPath, "Data/EnemyInfo.json");
                EnemyInfo enemyInfo = JsonUtility.FromJson<EnemyInfo>(File.ReadAllText(path));
                _instance.enemyInfoTable.Add("Enemy", enemyInfo);       
            }
            return _instance;
        }
    }
}