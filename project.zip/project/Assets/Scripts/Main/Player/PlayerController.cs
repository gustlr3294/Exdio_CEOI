﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PlayerController : MonoBehaviour
{
    private PlayerInfo status;

    private GameObject hp;
    private Text hpText;

    private Transform groundCheck;
    public LayerMask groundMask;
    private BoxCollider2D groundCollider;
    private float checkRadius = 0.5f;
    private bool grounded = true;


    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private bool onPlatform = false;

    /* private Transform weapon;
     private PolygonCollider2D atkCollidder;
     private const float MaxAtkedDelay = 2.0f;
     private float attackedDelay = MaxAtkedDelay;
     private bool isAttacking = false;*/

    private Rigidbody2D rb;
    private Vector2 velocity;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        status = GameData.Instance.playerInfo;

        groundCheck = this.gameObject.transform.Find("GroundCheck");
        groundCollider = groundCheck.GetComponent<BoxCollider2D>();

        hp = GameObject.Find("Health");
        hpText = hp.GetComponent<Text>();
        /* weapon = this.gameObject.transform.Find("Weapon");
        atkCollidder = weapon.GetComponent<PolygonCollider2D>(); */
    }

    private void FixedUpdate()
    {
        Movement();
    }

    private void Update()
    {
        hpText.text = status.hp.ToString();

        UpdateAnimation();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Platform") { onPlatform = true; }
        else { onPlatform = false; }
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.tag == "Platform") { groundCollider.isTrigger = false; }
        else if(collider.tag == "Ground")
        {
            groundCollider.isTrigger = false;
            onPlatform = false;
        }
    }

    private void Movement()
    {
        grounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundMask);

        velocity = rb.velocity;
        velocity.x = Input.GetAxis("Horizontal");
        velocity = new Vector2(velocity.x * status.speed, rb.velocity.y);

        if (spriteRenderer.flipX ? velocity.x > 0 : velocity.x < 0)
        {
            spriteRenderer.flipX = !spriteRenderer.flipX;
        }

        if (velocity.y == 0 && grounded)
        {
            if (Input.GetKeyDown(KeyCode.W))
            {
                velocity.y = status.jumpPower;
            }
            else if (Input.GetKeyDown(KeyCode.S) && onPlatform)
            {
                groundCollider.isTrigger = true;
            }
        }

        rb.velocity = velocity;
    }
    
    private void UpdateAnimation()
    {
        animator.SetFloat("velocityX", Mathf.Abs(velocity.x));
        animator.SetBool("grounded", grounded);
    }
}