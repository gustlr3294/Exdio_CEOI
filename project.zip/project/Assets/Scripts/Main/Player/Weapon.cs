﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    private Vector2 pos;
    private Vector2 target;

    public GameObject bullet;
    private const int amount = 10;
    private ObjectPoolManager bulletPool;
    private List<GameObject> bulletList;
    
    private void Awake()
    {
        bulletPool = new ObjectPoolManager();
        bulletList = new List<GameObject>();        
    }

    private void Start()
    {
        bulletPool.Create(bullet, amount);
    }

    private void Update()
    {
        pos = this.transform.position;
        target = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Quaternion rotation = Quaternion.Euler(0, 0, GetDgree(pos, target));
        transform.rotation = rotation;

        
        if (Input.GetMouseButtonDown(0)) { ShootBullet(rotation); }
        
        DisposalBullet();
    }

    public float GetDgree(Vector2 from, Vector2 to)
    {
        return Mathf.Atan2(to.y - from.y, to.x - from.x) * Mathf.Rad2Deg;
    }
    
    public void ShootBullet(Quaternion direction)
    {
        if(bulletList.Count == amount) { return; }

        bulletList.Add(bulletPool.NewItem());
        bulletList[bulletList.Count - 1].transform.position = transform.position;
        bulletList[bulletList.Count - 1].transform.rotation = direction;
    }
    
    public void DisposalBullet()
    {
        for (int i = 0; i < bulletList.Count; i++)
        {
            if(!bulletList[i].GetComponent<Bullet>().IsAlive)
            {
                bulletPool.RemoveItem(bulletList[i]);
                bulletList.RemoveAt(i);
            }
        }
    }
}