﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public float speed = 1f;
    int moveFlag = 0;   // 0:제자리 1:왼쪽 2:오른쪽. 
    private GameObject traceTarget;
    private bool TracingMode = false;
    private bool FightMode = false;
    private Animator animator;

    private EnemyInfo status;

    void Start()
    {
        status = new EnemyInfo(GameData.Instance.enemyInfoTable[gameObject.name] as EnemyInfo);
        animator = GetComponent<Animator>();

        StartCoroutine("ChangeMovement");
        StartCoroutine("ShowStatus");
    }

    void Update()
    {
        Move();
    }

    void Move()
    {
        Vector3 moveVelocity = Vector3.zero;
        string dist = "";

        //추격상태.
        if (TracingMode)
        {
            Vector3 playerPos = traceTarget.transform.position;

            if (playerPos.x < transform.position.x)
            {
                dist = "Left";
            }
            else if (playerPos.x > transform.position.x)
            {
                dist = "Right";
            }
        }

        //전투상태.
        else if (FightMode)
        {
            TracingMode = false;
            traceTarget = GameObject.FindGameObjectWithTag("Player");
            transform.position = Vector2.MoveTowards(transform.position, traceTarget.transform.position, speed * Time.deltaTime);
        }

        else
        {
            if (moveFlag == 1)
            {
                dist = "Left";
            }
            else if (moveFlag == 2)
            {
                dist = "Right";
            }
        }

        //방향.
        if (dist == "Left")
        {
            Vector3 scale = transform.localScale;
            scale.x = -Mathf.Abs(scale.x);
            moveVelocity = Vector3.left;
            transform.localScale = scale;
        }
        else if (dist == "Right")
        {
            Vector3 scale = transform.localScale;
            scale.x = +Mathf.Abs(scale.x);
            moveVelocity = Vector3.right;
            transform.localScale = scale;
        }

        transform.Translate(moveVelocity * speed * Time.deltaTime);
    }

    IEnumerator ChangeMovement()
    {
        moveFlag = Random.Range(0, 3);

        yield return new WaitForSeconds(3f);
        StartCoroutine("ChangeMovement");
    }

    IEnumerator ShowStatus()
    {
        if (TracingMode)
        {
            Debug.Log(status.hp + " / TracingMode");
        }
        else if (FightMode)
        {
            Debug.Log(status.hp + " / FightMode");
        }
        else
        {
            Debug.Log(status.hp + " / SafetyMode");
        }

        yield return new WaitForSeconds(1f);
        StartCoroutine("ShowStatus");
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Weapon")
        {
            status.hp--;

            FightMode = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            traceTarget = other.gameObject;
            StopCoroutine("ChangeMovement");
        }
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            TracingMode = true;
            float dis = Vector2.Distance(traceTarget.transform.position, transform.position);
            if (FightMode == true)
            {
                if (dis < 3f)
                {
                    animator.SetBool("skill_1", true);
                    speed = 0f;
                }
                else
                {
                    speed = 1f;
                }
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            TracingMode = false;
            StartCoroutine("ChangeMovement");
        }
    }
}