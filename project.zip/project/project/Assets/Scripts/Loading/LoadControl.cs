﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadControl : MonoBehaviour
{
    private Transform target;
    public GameObject message;

    private SpriteRenderer spriteRenderer;
    public Sprite nextSprite;
    private Color newColor;
    private float alpha = 1.0f;

    private AsyncOperation operation;
    
    private void Start ()
    {
        target = this.gameObject.transform.parent;

        spriteRenderer = message.GetComponent<SpriteRenderer>();
        newColor = spriteRenderer.color;

        StartCoroutine(LoadScene());
	}
    
    private IEnumerator LoadScene()
    {
        yield return null;

        operation = SceneManager.LoadSceneAsync("Stage");
        operation.allowSceneActivation = false;

        while (!operation.isDone)
        {
            yield return null;

            target.Rotate(new Vector3(0, 0, 3));

            if (operation.progress >= 0.9f)
            {
                spriteRenderer.sprite = nextSprite;

                if (newColor.a < 0 || newColor.a > 1) { alpha = -alpha; }
                newColor.a -= Time.deltaTime * alpha;
                spriteRenderer.color = newColor;

                if (Input.anyKey)
                {
                    operation.allowSceneActivation = true;
                }
            }
        }
    }
}
