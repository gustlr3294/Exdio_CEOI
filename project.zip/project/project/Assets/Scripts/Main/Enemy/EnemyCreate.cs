﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCreate : MonoBehaviour
{
    private ObjectPoolManager objPoolManager;

    public GameObject[] enemy;
    private List<GameObject> enemyList;

    public int enemyCount = 0; // Parsing Data

    private void Awake()
    {
        objPoolManager = new ObjectPoolManager();
        objPoolManager.Create(enemy[0], enemyCount);

        enemyList = new List<GameObject>();
        
        for (int i = 0; i < enemyCount; i++)
        {
            enemyList.Add(objPoolManager.NewItem());
        }
    }
}
