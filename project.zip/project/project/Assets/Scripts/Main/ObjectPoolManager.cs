﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPoolManager : IEnumerable, System.IDisposable
{
    class Item
    {
        public bool active;
        public GameObject gameObject;
    }
    List<Item> list;
    GameObject originalPrefab;

    public IEnumerator GetEnumerator()
    {
        if (list == null) { yield break; }

        int count = list.Count;
        for (int i = 0; i < count; i++)
        {
            Item item = list[i];
            if (item.active)
                yield return item.gameObject;
        }
    }

    public void Create(GameObject original, int count)
    {
        Dispose();

        list = new List<Item>();
        originalPrefab = original;

        for (int i = 0; i < count; i++)
        {
            Item item = new Item();
            item.active = false;
            item.gameObject = GameObject.Instantiate(original);
            item.gameObject.name = original.name;
            item.gameObject.SetActive(false);
            list.Add(item);
        }
    }

    public GameObject NewItem()
    {
        if (list == null) { return null; }
       

        int count = list.Count;

        for (int i = 0; i < count; i++)
        {
            Item item = list[i];
            if (item.active == false)
            {
                item.active = true;
                item.gameObject.SetActive(true);
                return item.gameObject;
            }
        }

        return null;
/*        Item n_item = new Item();
        n_item.active = false;
        n_item.gameObject = GameObject.Instantiate(originalPrefab);
        n_item.gameObject.SetActive(n_item.active);
        list.Add(n_item);

        return n_item.gameObject;*/
    }
    
    public void RemoveItem(GameObject gameObject)
    {
        if (list == null || gameObject == null) { return; }
        int count = list.Count;

        for (int i = 0; i < count; i++)
        {
            Item item = list[i];
            if (item.gameObject == gameObject)
            {
                item.active = false;
                item.gameObject.SetActive(false);
                break;
            }
        }
    }

    public void ClearItem()
    {
        if (list == null) { return; }
        int count = list.Count;

        for (int i = 0; i < count; i++)
        {
            Item item = list[i];
            if (item != null && item.active)
            {
                item.active = false;
                item.gameObject.SetActive(false);
            }
        }
    }

    public void Dispose()
    {
        if (list == null) { return; }
        int count = list.Count;

        for (int i = 0; i < count; i++)
        {
            Item item = list[i];
            GameObject.Destroy(item.gameObject);
        }
        list = null;
    }    
}
