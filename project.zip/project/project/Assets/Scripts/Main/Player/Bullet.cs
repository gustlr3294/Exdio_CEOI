﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public bool IsAlive { get; set; }
    private const float lifeTime = 6.0f;
    private float elapsedTime = 0.0f;
    private float speed = 15.0f;    

    private void OnEnable()
    {
        IsAlive = true;
        elapsedTime = 0.0f;
    }

    private void Update()
    {
        if (elapsedTime < lifeTime) { elapsedTime += Time.deltaTime; }
        else { IsAlive = false; }

        Movement();
    }
    
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Player" || collision.collider.tag == "Weapon")
        {
            Physics2D.IgnoreCollision(collision.collider, GetComponent<Collider2D>());
        }
        else { IsAlive = false; }
    }
        
    public void Movement()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime);
    }
}
